SWICKARD AUTO GROUP - CUSTOMER CONTACT LIST
Prepared for: FUGU (fugutech.co)
Date: 2025-12-01
Total Contacts: 16,125
Dealerships: 25

FIELDS:
- Dealership: Dealership name
- First Name: Customer first name
- Last Name: Customer last name
- Full Name: Complete customer name
- Phone: 10-digit phone number (digits only, no formatting)
- Email: Email address (lowercase, validated)

DATA QUALITY:
- Valid Emails: 16,125 (100.0%)
- Valid Phones: 16,122 (100.0%)
- Match Rate (Email+Phone): 16,122 (100.0%)

DATA SOURCE:
- Customer.io segments: SMS Approved, New Cars SMS Engaged, Used Cars SMS Engaged
- Exported: 2025-12-01

MATCH KEYS:
- Primary: Email + Phone
- FUGU will use these identifiers for customer matching

CONTACT:
- Swickard Auto Group
- Email Marketing Team

NOTES:
- Limited to 645 contacts per dealership (from 25 dealerships)
- Excluded Dealerships: Volvo Southwest Houston, MB South Austin, Porsche Seattle North,
  Porsche Anchorage, GMC Palmer, Audi/Volks Bellingham, BMW Lynnwood, BMW Portland,
  BMW Eugene, MB Thousand Oaks, Chevy Thousand Oaks
- All phone numbers standardized to 10 digits (US format)
- All email addresses converted to lowercase
- Invalid/missing data represented as empty fields
- See Data-Quality-Report.txt for detailed metrics
